package layout;

import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.PerspectiveCamera;
import javafx.scene.SubScene;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Sphere;
import javafx.scene.transform.Rotate;
import javafx.scene.transform.Translate;
import layout.utils3D.Xform;

public class Array3DPane extends BorderPane implements  ControlPane{
	
    double mousePosX;
    double mousePosY;
    double mouseOldX;
    double mouseOldY;
    double mouseDeltaX;
    double mouseDeltaY;
   
    /**
     * This is the group which rotates 
     */
	Xform root3D;
	
	/**
	 * The camnera to 
	 */
	Xform cameraXForm ;
	private Rotate rotateY;
	private Rotate rotateX;
	private Translate translate;
	
	/**
	 * Reference to to the mainm view. 
	 */
	private ArrayModelView mainView; 

	public Array3DPane(ArrayModelView mainView){
		this.mainView=mainView;
		
		root3D=new Xform(); 
		
		final PhongMaterial redMaterial = new PhongMaterial();
	       redMaterial.setSpecularColor(Color.ORANGE);
	       redMaterial.setDiffuseColor(Color.RED);		
	       
	    Sphere mySphere;
		for (int i=0; i<300; i++){
			mySphere = new Sphere(20);
			mySphere.setTranslateX(Math.random()*500);
			mySphere.setTranslateY(Math.random()*500);
			mySphere.setTranslateZ(Math.random()*200);
			mySphere.setMaterial(redMaterial);
	        root3D.getChildren().add(mySphere);
		}
  
    
        // Create and position camera
        PerspectiveCamera camera = new PerspectiveCamera(true);
        camera.getTransforms().addAll (
                rotateY=new Rotate(0, Rotate.Y_AXIS),
                rotateX=new Rotate(0, Rotate.X_AXIS),
                translate=new Translate(0, 0, -150));
        camera.setFarClip(Double.MAX_VALUE);

        
        root3D.setTranslate(150, 150, 0);
        root3D.getChildren().add(camera); 
 
        // Use a SubScene       
        SubScene subScene = new SubScene(root3D, 500,500);
        subScene.widthProperty().bind(this.widthProperty());
        subScene.heightProperty().bind(this.heightProperty());

        subScene.setFill(Color.WHITE);
        subScene.setCamera(camera);
        
        Group group = new Group();
        group.getChildren().add(subScene);
        
        handleMouse(subScene, root3D); 
        
        this.getChildren().add(group);
        
	}
	
	 private void handleMouse(SubScene scene, final Node root) {
	    	
	        scene.setOnMousePressed(new EventHandler<MouseEvent>() {

				@Override public void handle(MouseEvent me) {
	                mousePosX = me.getSceneX();
	                mousePosY = me.getSceneY();
	                mouseOldX = me.getSceneX();
	                mouseOldY = me.getSceneY();
	            }
	        });
	        
	        scene.setOnScroll(new EventHandler<ScrollEvent>() {
	            @Override public void handle(ScrollEvent event) {
	            	System.out.println("Scroll Event: "+event.getDeltaX() + " "+event.getDeltaY()); 
                	translate.setZ(translate.getZ()+  event.getDeltaY() *0.001*translate.getZ());   // + 

	            	
	            }
	        });
	        
	        
	        scene.setOnMouseDragged(new EventHandler<MouseEvent>() {

				@Override
	            public void handle(MouseEvent me) {
	                mouseOldX = mousePosX;
	                mouseOldY = mousePosY;
	                mousePosX = me.getSceneX();
	                mousePosY = me.getSceneY();
	                mouseDeltaX = (mousePosX - mouseOldX);
	                mouseDeltaY = (mousePosY - mouseOldY);

	                double modifier = 1.0;
	                double modifierFactor = 0.1;

	                if (me.isControlDown()) {
	                    modifier = 0.1;
	                }
	                if (me.isShiftDown()) {
	                    modifier = 10.0;
	                }
	                if (me.isPrimaryButtonDown()) {
	                	rotateY.setAngle(rotateY.getAngle() + mouseDeltaX * modifierFactor * modifier * 2.0);  // +
	                	rotateX.setAngle(rotateX.getAngle() - mouseDeltaY * modifierFactor * modifier * 2.0);  // -
	                }
	                if (me.isSecondaryButtonDown()) {
	                	translate.setX(translate.getX() -mouseDeltaX * modifierFactor * modifier * 5);
	                	translate.setY(translate.getY() - mouseDeltaY * modifierFactor * modifier * 5);   // +
	                }
	              
	               
	            }
	        });
	    }

	@Override
	public void notifyChange(ChangeType type) {
		// TODO Auto-generated method stub
		
	}
	
	

}
