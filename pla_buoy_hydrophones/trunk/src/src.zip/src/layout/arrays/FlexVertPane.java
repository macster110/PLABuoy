package layout.arrays;

import dataUnits.hArray.FlexibleVerticalArray;

public class FlexVertPane extends HArrayPane<FlexibleVerticalArray>{
	
	public FlexVertPane(){
		super();
		//this.getChildren().add(new Label("Flex"));
	}

	@Override
	public int getParams(FlexibleVerticalArray array) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void setParams(FlexibleVerticalArray array) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean showErrorWarning(int errorType) {
		// TODO Auto-generated method stub
		return false;
	}

	

}
